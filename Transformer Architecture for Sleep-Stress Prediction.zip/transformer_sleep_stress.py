"""
Transformer-Based Deep Learning for Sleep-Stress Dynamics
Advanced architecture incorporating:
- Multi-head self-attention
- Positional encoding
- Encoder-decoder structure
- Cross-attention between sleep and stress
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

# Since we don't have TensorFlow/PyTorch, we'll implement a simplified
# transformer architecture using NumPy and scikit-learn components

class PositionalEncoding:
    """Positional encoding for sequence data."""
    
    def __init__(self, d_model, max_len=100):
        """
        Args:
            d_model: Dimension of the model (embedding size)
            max_len: Maximum sequence length
        """
        self.d_model = d_model
        self.max_len = max_len
        
        # Create positional encoding matrix
        position = np.arange(max_len)[:, np.newaxis]
        div_term = np.exp(np.arange(0, d_model, 2) * -(np.log(10000.0) / d_model))
        
        pe = np.zeros((max_len, d_model))
        pe[:, 0::2] = np.sin(position * div_term)
        pe[:, 1::2] = np.cos(position * div_term)
        
        self.pe = pe
    
    def encode(self, x, seq_positions):
        """Add positional encoding to input."""
        # x shape: (batch, seq_len, features)
        # Add positional encoding
        encoded = np.zeros_like(x)
        for i, pos in enumerate(seq_positions):
            if pos < self.max_len:
                # Add positional encoding to all features
                encoded[i] = x[i] + self.pe[pos, :x.shape[-1]]
        return encoded


class MultiHeadAttention:
    """
    Simplified multi-head attention mechanism.
    Uses matrix operations to compute attention scores.
    """
    
    def __init__(self, d_model, num_heads):
        """
        Args:
            d_model: Model dimension
            num_heads: Number of attention heads
        """
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        # Initialize weights (in practice, these would be learned)
        np.random.seed(42)
        self.W_q = np.random.randn(d_model, d_model) * 0.01
        self.W_k = np.random.randn(d_model, d_model) * 0.01
        self.W_v = np.random.randn(d_model, d_model) * 0.01
        self.W_o = np.random.randn(d_model, d_model) * 0.01
    
    def scaled_dot_product_attention(self, Q, K, V, mask=None):
        """
        Compute scaled dot-product attention.
        
        Args:
            Q: Queries (batch, num_heads, seq_len, d_k)
            K: Keys (batch, num_heads, seq_len, d_k)
            V: Values (batch, num_heads, seq_len, d_k)
            mask: Optional mask
        """
        # Compute attention scores
        # K transpose: (batch, num_heads, d_k, seq_len)
        scores = np.matmul(Q, K.transpose(0, 1, 3, 2)) / np.sqrt(self.d_k)
        
        if mask is not None:
            scores = scores + mask
        
        # Softmax
        attention_weights = self.softmax(scores)
        
        # Apply attention to values
        output = np.matmul(attention_weights, V)
        
        return output, attention_weights
    
    def softmax(self, x):
        """Numerically stable softmax."""
        exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)
    
    def forward(self, query, key, value, mask=None):
        """
        Forward pass through multi-head attention.
        
        Args:
            query, key, value: Input tensors (batch, seq_len, d_model)
            mask: Optional attention mask
        """
        batch_size = query.shape[0]
        
        # Linear projections
        Q = np.matmul(query, self.W_q)
        K = np.matmul(key, self.W_k)
        V = np.matmul(value, self.W_v)
        
        # Split into multiple heads
        Q = self.split_heads(Q, batch_size)
        K = self.split_heads(K, batch_size)
        V = self.split_heads(V, batch_size)
        
        # Apply attention
        attn_output, attn_weights = self.scaled_dot_product_attention(Q, K, V, mask)
        
        # Concatenate heads
        attn_output = self.combine_heads(attn_output, batch_size)
        
        # Final linear projection
        output = np.matmul(attn_output, self.W_o)
        
        return output, attn_weights
    
    def split_heads(self, x, batch_size):
        """Split into multiple attention heads."""
        # Reshape to (batch, num_heads, seq_len, d_k)
        x = x.reshape(batch_size, -1, self.num_heads, self.d_k)
        return x.transpose(0, 2, 1, 3)
    
    def combine_heads(self, x, batch_size):
        """Combine multiple attention heads."""
        # Transpose and reshape
        x = x.transpose(0, 2, 1, 3)
        return x.reshape(batch_size, -1, self.d_model)


class FeedForward:
    """Position-wise feed-forward network."""
    
    def __init__(self, d_model, d_ff, dropout=0.1):
        """
        Args:
            d_model: Model dimension
            d_ff: Feed-forward dimension (usually 4*d_model)
            dropout: Dropout rate
        """
        self.d_model = d_model
        self.d_ff = d_ff
        self.dropout = dropout
        
        # Initialize weights
        np.random.seed(42)
        self.W1 = np.random.randn(d_model, d_ff) * np.sqrt(2.0 / d_model)
        self.b1 = np.zeros(d_ff)
        self.W2 = np.random.randn(d_ff, d_model) * np.sqrt(2.0 / d_ff)
        self.b2 = np.zeros(d_model)
    
    def relu(self, x):
        """ReLU activation."""
        return np.maximum(0, x)
    
    def forward(self, x):
        """Forward pass."""
        # First linear + ReLU
        x = self.relu(np.matmul(x, self.W1) + self.b1)
        
        # Dropout (simplified - just scaling)
        x = x * (1 - self.dropout)
        
        # Second linear
        x = np.matmul(x, self.W2) + self.b2
        
        return x


class TransformerBlock:
    """Single transformer encoder block."""
    
    def __init__(self, d_model, num_heads, d_ff, dropout=0.1):
        """
        Args:
            d_model: Model dimension
            num_heads: Number of attention heads
            d_ff: Feed-forward dimension
            dropout: Dropout rate
        """
        self.attention = MultiHeadAttention(d_model, num_heads)
        self.feed_forward = FeedForward(d_model, d_ff, dropout)
        self.layer_norm1 = LayerNorm(d_model)
        self.layer_norm2 = LayerNorm(d_model)
        self.dropout = dropout
    
    def forward(self, x, mask=None):
        """Forward pass through transformer block."""
        # Multi-head attention + residual + layer norm
        attn_output, attn_weights = self.attention.forward(x, x, x, mask)
        x = self.layer_norm1.forward(x + attn_output)
        
        # Feed-forward + residual + layer norm
        ff_output = self.feed_forward.forward(x)
        x = self.layer_norm2.forward(x + ff_output)
        
        return x, attn_weights


class LayerNorm:
    """Layer normalization."""
    
    def __init__(self, d_model, eps=1e-6):
        """
        Args:
            d_model: Model dimension
            eps: Small constant for numerical stability
        """
        self.eps = eps
        self.gamma = np.ones(d_model)
        self.beta = np.zeros(d_model)
    
    def forward(self, x):
        """Forward pass."""
        mean = np.mean(x, axis=-1, keepdims=True)
        std = np.std(x, axis=-1, keepdims=True)
        return self.gamma * (x - mean) / (std + self.eps) + self.beta


class SleepStressTransformer:
    """
    Transformer model for sleep-stress prediction.
    
    Architecture:
    1. Embedding layer for sleep and stress features
    2. Positional encoding
    3. Multiple transformer encoder blocks
    4. Cross-attention between sleep and stress
    5. Prediction head
    """
    
    def __init__(self, 
                 sleep_dim=4,
                 stress_dim=1,
                 d_model=32,
                 num_heads=4,
                 num_layers=3,
                 d_ff=128,
                 seq_len=7,
                 dropout=0.1):
        """
        Args:
            sleep_dim: Number of sleep features
            stress_dim: Number of stress features
            d_model: Model dimension (embedding size)
            num_heads: Number of attention heads
            num_layers: Number of transformer blocks
            d_ff: Feed-forward dimension
            seq_len: Sequence length
            dropout: Dropout rate
        """
        self.sleep_dim = sleep_dim
        self.stress_dim = stress_dim
        self.d_model = d_model
        self.num_heads = num_heads
        self.num_layers = num_layers
        self.d_ff = d_ff
        self.seq_len = seq_len
        
        # Embedding layers (linear projections)
        np.random.seed(42)
        self.sleep_embedding = np.random.randn(sleep_dim, d_model) * 0.01
        self.stress_embedding = np.random.randn(stress_dim, d_model) * 0.01
        
        # Positional encoding
        self.pos_encoder = PositionalEncoding(d_model, max_len=100)
        
        # Transformer blocks
        self.encoder_blocks = [
            TransformerBlock(d_model, num_heads, d_ff, dropout)
            for _ in range(num_layers)
        ]
        
        # Cross-attention between sleep and stress
        self.cross_attention = MultiHeadAttention(d_model, num_heads)
        
        # Prediction head
        self.output_projection = np.random.randn(d_model, sleep_dim) * 0.01
        
        # Store attention weights for visualization
        self.attention_weights = []
    
    def embed_and_encode(self, sleep_seq, stress_seq):
        """
        Embed inputs and add positional encoding.
        
        Args:
            sleep_seq: Sleep sequence (batch, seq_len, sleep_dim)
            stress_seq: Stress sequence (batch, seq_len, stress_dim)
        
        Returns:
            sleep_encoded, stress_encoded: Encoded sequences
        """
        batch_size, seq_len, _ = sleep_seq.shape
        
        # Linear projection to d_model
        sleep_embedded = np.matmul(sleep_seq, self.sleep_embedding)
        stress_embedded = np.matmul(stress_seq, self.stress_embedding)
        
        # Add positional encoding
        positions = np.arange(seq_len)
        sleep_encoded = self.pos_encoder.encode(sleep_embedded, positions)
        stress_encoded = self.pos_encoder.encode(stress_embedded, positions)
        
        return sleep_encoded, stress_encoded
    
    def forward(self, sleep_seq, stress_seq):
        """
        Forward pass through the transformer.
        
        Args:
            sleep_seq: Sleep sequence (batch, seq_len, sleep_dim)
            stress_seq: Stress sequence (batch, seq_len, stress_dim)
        
        Returns:
            predictions: Predicted sleep features (batch, sleep_dim)
        """
        # Embed and encode
        sleep_encoded, stress_encoded = self.embed_and_encode(sleep_seq, stress_seq)
        
        # Pass through encoder blocks
        self.attention_weights = []
        for block in self.encoder_blocks:
            sleep_encoded, attn = block.forward(sleep_encoded)
            self.attention_weights.append(attn)
        
        # Cross-attention: Query from stress, Key/Value from sleep
        cross_output, cross_attn = self.cross_attention.forward(
            stress_encoded, sleep_encoded, sleep_encoded
        )
        
        # Combine sleep and cross-attention
        combined = sleep_encoded + cross_attn
        
        # Take the last time step
        last_hidden = combined[:, -1, :]
        
        # Project to output
        predictions = np.matmul(last_hidden, self.output_projection)
        
        return predictions
    
    def get_attention_maps(self):
        """Return attention weights for visualization."""
        return self.attention_weights


class TransformerSleepPredictor:
    """
    High-level wrapper for training and using the transformer model.
    """
    
    def __init__(self, seq_len=7, d_model=32, num_heads=4, num_layers=3):
        """
        Args:
            seq_len: Length of input sequences (days)
            d_model: Model dimension
            num_heads: Number of attention heads
            num_layers: Number of transformer layers
        """
        self.seq_len = seq_len
        self.d_model = d_model
        self.num_heads = num_heads
        self.num_layers = num_layers
        
        self.model = None
        self.sleep_scaler = StandardScaler()
        self.stress_scaler = StandardScaler()
        self.history = {'train_loss': [], 'val_loss': []}
    
    def prepare_sequences(self, sleep_data, stress_data):
        """
        Prepare sequences for training.
        
        Args:
            sleep_data: Sleep features (n_samples, sleep_dim)
            stress_data: Stress values (n_samples, 1)
        
        Returns:
            X_sleep, X_stress, y: Sequences and targets
        """
        n_samples = len(sleep_data)
        sleep_dim = sleep_data.shape[1]
        
        X_sleep = []
        X_stress = []
        y = []
        
        for i in range(self.seq_len, n_samples):
            # Input: past seq_len days
            sleep_seq = sleep_data[i-self.seq_len:i]
            stress_seq = stress_data[i-self.seq_len:i].reshape(-1, 1)
            
            # Target: next day's sleep
            target = sleep_data[i]
            
            X_sleep.append(sleep_seq)
            X_stress.append(stress_seq)
            y.append(target)
        
        return np.array(X_sleep), np.array(X_stress), np.array(y)
    
    def train(self, sleep_data, stress_data, epochs=100, batch_size=8, 
              learning_rate=0.001, validation_split=0.2, verbose=True):
        """
        Train the transformer model using gradient descent.
        
        This is a simplified training loop using basic gradient descent.
        In practice, you'd use Adam optimizer with proper backpropagation.
        """
        # Normalize data
        sleep_normalized = self.sleep_scaler.fit_transform(sleep_data)
        stress_normalized = self.stress_scaler.fit_transform(stress_data.reshape(-1, 1))
        
        # Prepare sequences
        X_sleep, X_stress, y = self.prepare_sequences(sleep_normalized, stress_normalized.flatten())
        
        if verbose:
            print(f"Prepared {len(X_sleep)} sequences")
            print(f"Sleep sequence shape: {X_sleep.shape}")
            print(f"Stress sequence shape: {X_stress.shape}")
            print(f"Target shape: {y.shape}")
        
        # Split train/val
        split_idx = int(len(X_sleep) * (1 - validation_split))
        X_sleep_train, X_sleep_val = X_sleep[:split_idx], X_sleep[split_idx:]
        X_stress_train, X_stress_val = X_stress[:split_idx], X_stress[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]
        
        # Initialize model
        self.model = SleepStressTransformer(
            sleep_dim=sleep_data.shape[1],
            stress_dim=1,
            d_model=self.d_model,
            num_heads=self.num_heads,
            num_layers=self.num_layers,
            seq_len=self.seq_len
        )
        
        if verbose:
            print(f"\nModel initialized:")
            print(f"  d_model: {self.d_model}")
            print(f"  num_heads: {self.num_heads}")
            print(f"  num_layers: {self.num_layers}")
            print(f"  seq_len: {self.seq_len}")
        
        # Simplified training (forward pass only for demonstration)
        # In practice, you'd implement proper backpropagation
        if verbose:
            print(f"\nRunning {epochs} forward passes for demonstration...")
        
        for epoch in range(min(epochs, 10)):  # Limit to 10 for demo
            # Forward pass on training data
            y_pred_train = self.model.forward(X_sleep_train, X_stress_train)
            train_loss = np.mean((y_pred_train - y_train)**2)
            
            # Forward pass on validation data
            y_pred_val = self.model.forward(X_sleep_val, X_stress_val)
            val_loss = np.mean((y_pred_val - y_val)**2)
            
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            
            if verbose and epoch % 2 == 0:
                print(f"  Epoch {epoch+1}/{min(epochs, 10)}: "
                      f"train_loss={train_loss:.4f}, val_loss={val_loss:.4f}")
        
        if verbose:
            print("\nNote: This is a demonstration. Full training would require")
            print("backpropagation and optimization, which needs TensorFlow/PyTorch.")
            print("The model structure is correct but weights are not actually trained.")
        
        return self.history
    
    def predict(self, sleep_seq, stress_seq):
        """
        Make predictions using the trained model.
        
        Args:
            sleep_seq: Sleep sequence (seq_len, sleep_dim)
            stress_seq: Stress sequence (seq_len,)
        
        Returns:
            prediction: Predicted sleep features
        """
        # Normalize
        sleep_normalized = self.sleep_scaler.transform(sleep_seq)
        stress_normalized = self.stress_scaler.transform(stress_seq.reshape(-1, 1))
        
        # Add batch dimension
        sleep_batch = sleep_normalized[np.newaxis, :, :]
        stress_batch = stress_normalized[np.newaxis, :, :]
        
        # Predict
        pred_normalized = self.model.forward(sleep_batch, stress_batch)[0]
        
        # Denormalize
        prediction = self.sleep_scaler.inverse_transform(pred_normalized.reshape(1, -1))[0]
        
        return prediction
    
    def visualize_attention(self, sleep_seq, stress_seq, save_path=None):
        """
        Visualize attention weights.
        
        Args:
            sleep_seq: Sleep sequence for visualization
            stress_seq: Stress sequence for visualization
            save_path: Path to save figure
        """
        # Get prediction (this computes attention)
        _ = self.predict(sleep_seq, stress_seq)
        
        # Get attention weights
        attention_weights = self.model.get_attention_maps()
        
        if len(attention_weights) == 0:
            print("No attention weights available")
            return
        
        # Plot attention maps
        num_layers = len(attention_weights)
        fig, axes = plt.subplots(1, num_layers, figsize=(5*num_layers, 4))
        
        if num_layers == 1:
            axes = [axes]
        
        for i, attn in enumerate(attention_weights):
            # Average over heads and batch
            attn_avg = attn.mean(axis=(0, 1))
            
            ax = axes[i]
            im = ax.imshow(attn_avg, cmap='viridis', aspect='auto')
            ax.set_title(f'Layer {i+1} Attention', fontweight='bold')
            ax.set_xlabel('Key Position (Day)', fontweight='bold')
            ax.set_ylabel('Query Position (Day)', fontweight='bold')
            plt.colorbar(im, ax=ax, label='Attention Weight')
        
        plt.suptitle('Multi-Head Self-Attention Weights', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Saved attention visualization to {save_path}")
        
        return fig


def create_comprehensive_architecture_comparison():
    """
    Compare different architectures for sleep-stress modeling.
    """
    print("=" * 80)
    print("TRANSFORMER vs TRADITIONAL ARCHITECTURES COMPARISON")
    print("=" * 80)
    print()
    
    architectures = {
        'Simple MLP': {
            'description': 'Basic feedforward network',
            'params': 'Input → Dense(64) → Dense(32) → Output',
            'pros': ['Fast', 'Simple', 'Interpretable'],
            'cons': ['No temporal modeling', 'Limited capacity'],
            'use_case': 'Quick baseline, small datasets'
        },
        'RNN/LSTM': {
            'description': 'Recurrent neural network',
            'params': 'Input → LSTM(64) → LSTM(32) → Output',
            'pros': ['Sequential data', 'Variable length', 'Memory'],
            'cons': ['Vanishing gradients', 'Slow training', 'Limited long-term'],
            'use_case': 'Time series with moderate dependencies'
        },
        'CNN 1D': {
            'description': 'Convolutional neural network',
            'params': 'Input → Conv1D(64,3) → Conv1D(32,3) → Output',
            'pros': ['Local patterns', 'Fast', 'Parallel'],
            'cons': ['Fixed receptive field', 'No long-range'],
            'use_case': 'Local temporal patterns (sleep stages)'
        },
        'ResNet': {
            'description': 'Residual network (our flow map)',
            'params': 'x_{t+1} = x_t + N(x_t, ..., x_{t-k})',
            'pros': ['Stable gradients', 'Deep networks', 'Skip connections'],
            'cons': ['Still feedforward', 'No attention'],
            'use_case': 'Deep models, learning changes/residuals'
        },
        'Transformer': {
            'description': 'Self-attention architecture',
            'params': 'Input → Attention × N → Output',
            'pros': ['Long-range dependencies', 'Parallel', 'Interpretable attention'],
            'cons': ['Data hungry', 'Computationally expensive'],
            'use_case': 'Complex patterns, sufficient data'
        },
        'Hybrid': {
            'description': 'CNN + Transformer',
            'params': 'Input → CNN(local) → Transformer(global) → Output',
            'pros': ['Best of both', 'Multi-scale', 'Efficient'],
            'cons': ['Complex', 'Hard to tune'],
            'use_case': 'State-of-the-art, large datasets'
        }
    }
    
    # Create comparison table
    import pandas as pd
    
    df_comparison = pd.DataFrame({
        'Architecture': list(architectures.keys()),
        'Description': [v['description'] for v in architectures.values()],
        'Parameters': [v['params'] for v in architectures.values()],
        'Best Use Case': [v['use_case'] for v in architectures.values()]
    })
    
    print("\nARCHITECTURE COMPARISON")
    print("-" * 80)
    print(df_comparison.to_string(index=False))
    
    print("\n\nDETAILED BREAKDOWN")
    print("-" * 80)
    for name, info in architectures.items():
        print(f"\n{name}:")
        print(f"  Description: {info['description']}")
        print(f"  ✓ Pros: {', '.join(info['pros'])}")
        print(f"  ✗ Cons: {', '.join(info['cons'])}")
        print(f"  → Use for: {info['use_case']}")
    
    return df_comparison


if __name__ == "__main__":
    print("=" * 80)
    print("TRANSFORMER ARCHITECTURE FOR SLEEP-STRESS PREDICTION")
    print("=" * 80)
    print()
    print("This module implements a Transformer-based deep learning model")
    print("with the following components:")
    print()
    print("1. Positional Encoding - Adds temporal information")
    print("2. Multi-Head Self-Attention - Captures dependencies")
    print("3. Cross-Attention - Models sleep-stress interaction")
    print("4. Feed-Forward Networks - Non-linear transformations")
    print("5. Layer Normalization - Stable training")
    print()
    print("Architecture:")
    print("  Input → Embedding → Positional Encoding → ")
    print("  Transformer Blocks × N → Cross-Attention → ")
    print("  Prediction Head → Output")
    print()
    print("=" * 80)
    
    # Create comparison
    create_comprehensive_architecture_comparison()
