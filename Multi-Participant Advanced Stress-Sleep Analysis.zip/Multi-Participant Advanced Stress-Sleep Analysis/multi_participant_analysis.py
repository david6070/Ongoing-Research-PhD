"""
Multi-Participant Advanced Stress-Sleep Analysis
Comprehensive analysis across 3 individuals with:
- Stress-sleep correlations
- Spectral cycle detection
- Dynamical systems analysis
- Cross-participant comparisons
- Population vs individual patterns
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import signal, stats
from scipy.fft import fft, fftfreq
from scipy.spatial.distance import pdist
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

sns.set_style("whitegrid")
plt.rcParams['figure.dpi'] = 100

print("=" * 80)
print("MULTI-PARTICIPANT ADVANCED STRESS-SLEEP ANALYSIS")
print("=" * 80)
print()

# ============================================================================
# STEP 1: Load All Participant Data
# ============================================================================
print("STEP 1: Loading Multi-Participant Data")
print("-" * 80)

# Load all three datasets
participants = {
    'P1': '/mnt/user-data/uploads/final_separated_sleep_ids.csv',
    'P2': '/mnt/user-data/uploads/final_separated_sleep_ids_0e615090.csv',
    'P3': '/mnt/user-data/uploads/final_separated_sleep_ids_7607c6de.csv'
}

data_dict = {}
for pid, filepath in participants.items():
    df = pd.read_csv(filepath)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    
    # Create composite stress
    stress_cols = ['stress_score_health', 'stress_score_job', 'stress_score_personality']
    df['stress_composite'] = df[stress_cols].mean(axis=1)
    
    # Fill missing values
    sleep_features = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct']
    for feat in sleep_features:
        df[feat] = df[feat].fillna(method='ffill').fillna(method='bfill')
    df['stress_composite'] = df['stress_composite'].fillna(df['stress_composite'].median())
    
    # Sleep quality metric
    df['sleep_quality'] = (
        0.3 * df['deep_pct'] + 
        0.2 * df['rem_pct'] - 
        0.3 * df['wake_pct'] +
        0.2 * df['light_pct']
    )
    
    # Sleep efficiency
    df['total_sleep_min'] = df['deep_min'] + df['light_min'] + df['rem_min']
    df['sleep_efficiency'] = (df['total_sleep_min'] / 
                              (df['total_sleep_min'] + df['wake_min']) * 100)
    
    data_dict[pid] = df
    
    print(f"{pid}: {len(df)} nights, {df['date'].min().date()} to {df['date'].max().date()}")
    stress_available = df['stress_composite'].notna().sum()
    print(f"     Stress data: {stress_available}/{len(df)} nights ({stress_available/len(df)*100:.1f}%)")

print(f"\nTotal nights across all participants: {sum(len(df) for df in data_dict.values())}")

# ============================================================================
# STEP 2: Individual Stress-Sleep Correlations
# ============================================================================
print("\n" + "=" * 80)
print("STEP 2: Stress-Sleep Correlations by Participant")
print("-" * 80)

# Variables for correlation
sleep_vars = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct', 
             'sleep_efficiency', 'sleep_quality']

# Calculate correlations for each participant
corr_results = {}
for pid, df in data_dict.items():
    corr_results[pid] = {}
    for var in sleep_vars:
        r = df[['stress_composite', var]].corr().iloc[0, 1]
        corr_results[pid][var] = r

# Create comparison visualization
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Heatmap
corr_df = pd.DataFrame(corr_results).T
im = ax1.imshow(corr_df.values, cmap='RdBu_r', aspect='auto', vmin=-0.5, vmax=0.5)
ax1.set_xticks(range(len(sleep_vars)))
ax1.set_xticklabels([v.replace('_', '\n') for v in sleep_vars], fontsize=9)
ax1.set_yticks(range(len(participants)))
ax1.set_yticklabels(list(participants.keys()), fontsize=10, fontweight='bold')
ax1.set_title('Stress-Sleep Correlations by Participant', 
             fontsize=12, fontweight='bold')

# Add values
for i in range(len(participants)):
    for j in range(len(sleep_vars)):
        text = ax1.text(j, i, f'{corr_df.values[i, j]:.3f}',
                       ha="center", va="center", color="black", fontsize=9)

plt.colorbar(im, ax=ax1, label='Correlation')

# Bar plot comparison
x = np.arange(len(sleep_vars))
width = 0.25
for i, (pid, corrs) in enumerate(corr_results.items()):
    offset = width * (i - 1)
    values = [corrs[var] for var in sleep_vars]
    ax2.bar(x + offset, values, width, label=pid, alpha=0.8, edgecolor='black')

ax2.set_ylabel('Correlation with Stress', fontsize=11, fontweight='bold')
ax2.set_xlabel('Sleep Variable', fontsize=11, fontweight='bold')
ax2.set_title('Stress-Sleep Correlation Comparison', fontsize=12, fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels([v.replace('_', '\n') for v in sleep_vars], fontsize=9)
ax2.axhline(y=0, color='black', linestyle='-', linewidth=1)
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('/home/claude/multi_01_correlations.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: multi_01_correlations.png")

print("\nCorrelation summary:")
for pid in participants.keys():
    print(f"\n{pid}:")
    for var in sleep_vars:
        r = corr_results[pid][var]
        sig = "***" if abs(r) > 0.3 else "**" if abs(r) > 0.2 else "*" if abs(r) > 0.1 else "ns"
        direction = "↓" if r < 0 else "↑"
        print(f"  {direction} {var:20s}: r = {r:+.3f} {sig}")

# ============================================================================
# STEP 3: Spectral Analysis - Cycle Detection
# ============================================================================
print("\n" + "=" * 80)
print("STEP 3: Spectral Analysis - Detecting Cycles")
print("-" * 80)

def detect_cycles(data, var_name, max_period=30):
    """Detect dominant cycles using FFT."""
    # Detrend
    detrended = signal.detrend(data)
    
    # Window
    window = signal.windows.hann(len(detrended))
    windowed = detrended * window
    
    # FFT
    n = len(windowed)
    yf = fft(windowed)
    xf = fftfreq(n, d=1.0)
    
    # Positive frequencies only
    positive_freq_idx = xf > 0
    xf = xf[positive_freq_idx]
    yf = 2.0/n * np.abs(yf[positive_freq_idx])
    
    # Convert to periods
    periods = 1.0 / xf
    
    # Focus on 2-30 day range
    period_mask = (periods >= 2) & (periods <= max_period)
    periods_filtered = periods[period_mask]
    power_filtered = yf[period_mask]
    
    # Find peaks
    peaks, properties = signal.find_peaks(power_filtered, prominence=0.01)
    
    if len(peaks) > 0:
        # Top 3 peaks
        top_peaks_idx = np.argsort(power_filtered[peaks])[-3:][::-1]
        top_peaks = peaks[top_peaks_idx]
        dominant_periods = periods_filtered[top_peaks].tolist()
    else:
        dominant_periods = []
    
    return periods_filtered, power_filtered, dominant_periods

# Detect cycles for each participant
cycle_results = {}
fig, axes = plt.subplots(3, 3, figsize=(18, 12))

variables = ['sleep_quality', 'stress_composite', 'deep_pct']

for row_idx, pid in enumerate(participants.keys()):
    df = data_dict[pid]
    cycle_results[pid] = {}
    
    for col_idx, var in enumerate(variables):
        ax = axes[row_idx, col_idx]
        data = df[var].values
        
        periods, power, dominant = detect_cycles(data, var)
        cycle_results[pid][var] = dominant
        
        # Plot
        ax.plot(periods, power, linewidth=1.5, alpha=0.8)
        
        # Mark dominant periods
        if len(dominant) > 0:
            for period in dominant[:3]:
                idx = np.argmin(np.abs(periods - period))
                ax.plot(period, power[idx], 'ro', markersize=8)
                ax.annotate(f'{period:.1f}d', 
                           xy=(period, power[idx]),
                           xytext=(period, power[idx] * 1.2),
                           fontsize=8, ha='center',
                           bbox=dict(boxstyle='round,pad=0.3', 
                                   facecolor='yellow', alpha=0.6))
        
        # Add reference lines
        ax.axvline(x=7, color='green', linestyle='--', alpha=0.4, 
                  linewidth=1, label='Weekly' if col_idx == 0 else '')
        
        ax.set_xlabel('Period (days)', fontsize=9, fontweight='bold')
        ax.set_ylabel('Power', fontsize=9, fontweight='bold')
        ax.set_title(f'{pid}: {var.replace("_", " ").title()}', 
                    fontsize=10, fontweight='bold')
        ax.set_xlim(2, 30)
        ax.grid(True, alpha=0.3)
        
        if col_idx == 0 and row_idx == 0:
            ax.legend(fontsize=8)

plt.suptitle('Spectral Analysis: Cycle Detection Across Participants', 
            fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/multi_02_spectral_cycles.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: multi_02_spectral_cycles.png")

print("\nDetected dominant cycles:")
for pid in participants.keys():
    print(f"\n{pid}:")
    for var in variables:
        cycles = cycle_results[pid][var]
        if len(cycles) > 0:
            cycles_str = ', '.join([f'{c:.1f}d' for c in cycles[:3]])
            print(f"  {var:20s}: {cycles_str}")
        else:
            print(f"  {var:20s}: No significant cycles")

# ============================================================================
# STEP 4: Lyapunov Exponents - Chaos Quantification
# ============================================================================
print("\n" + "=" * 80)
print("STEP 4: Lyapunov Exponents - Chaos Analysis")
print("-" * 80)

def lyapunov_exponent_simple(data, dim=3, tau=1, n_steps=5):
    """Simplified Lyapunov exponent calculation."""
    from sklearn.neighbors import NearestNeighbors
    
    # Time delay embedding
    N = len(data)
    m = N - (dim - 1) * tau
    
    if m < 20:
        return np.nan
    
    embedded = np.zeros((m, dim))
    for i in range(dim):
        embedded[:, i] = data[i * tau : i * tau + m]
    
    # Find nearest neighbors
    nbrs = NearestNeighbors(n_neighbors=2, algorithm='ball_tree').fit(embedded)
    distances, indices = nbrs.kneighbors(embedded)
    
    # Track divergence
    lyap_sum = 0
    count = 0
    
    for i in range(m - n_steps - 1):
        j = indices[i, 1]
        d0 = distances[i, 1]
        
        if i + n_steps < m and j + n_steps < m and d0 > 1e-10:
            d_final = np.linalg.norm(embedded[i + n_steps] - embedded[j + n_steps])
            
            if d_final > 1e-10:
                lyap_sum += np.log(d_final / d0)
                count += 1
    
    if count > 0:
        return lyap_sum / (count * n_steps * tau)
    else:
        return np.nan

# Calculate Lyapunov exponents
lyap_results = {}
test_vars = ['deep_pct', 'rem_pct', 'wake_pct', 'sleep_quality', 'stress_composite']

print("\nCalculating Lyapunov exponents...")
for pid in participants.keys():
    df = data_dict[pid]
    lyap_results[pid] = {}
    
    for var in test_vars:
        data = df[var].values
        lyap = lyapunov_exponent_simple(data)
        lyap_results[pid][var] = lyap

# Visualize
fig, ax = plt.subplots(figsize=(12, 6))

x = np.arange(len(test_vars))
width = 0.25

colors_p = ['#3498db', '#e74c3c', '#2ecc71']

for i, (pid, color) in enumerate(zip(participants.keys(), colors_p)):
    offset = width * (i - 1)
    values = [lyap_results[pid][var] for var in test_vars]
    ax.bar(x + offset, values, width, label=pid, alpha=0.8, 
          edgecolor='black', linewidth=1, color=color)

ax.axhline(y=0, color='black', linestyle='-', linewidth=2)
ax.set_ylabel('Lyapunov Exponent (λ)', fontsize=11, fontweight='bold')
ax.set_xlabel('Variable', fontsize=11, fontweight='bold')
ax.set_title('Lyapunov Spectrum Comparison\n(λ>0: Chaotic, λ<0: Stable)', 
            fontsize=12, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels([v.replace('_', '\n') for v in test_vars], fontsize=9)
ax.legend(fontsize=10, title='Participant', title_fontsize=11)
ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('/home/claude/multi_03_lyapunov.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: multi_03_lyapunov.png")

print("\nLyapunov exponents:")
for pid in participants.keys():
    print(f"\n{pid}:")
    for var in test_vars:
        lyap = lyap_results[pid][var]
        if not np.isnan(lyap):
            interp = "Chaotic" if lyap > 0 else "Stable"
            print(f"  {var:20s}: λ = {lyap:+.4f} ({interp})")

# ============================================================================
# STEP 5: DFA - Long-Range Correlations
# ============================================================================
print("\n" + "=" * 80)
print("STEP 5: Detrended Fluctuation Analysis")
print("-" * 80)

def dfa_simple(data, min_win=4, max_win=None, n_wins=8):
    """Simplified DFA calculation."""
    N = len(data)
    y = np.cumsum(data - np.mean(data))
    
    if max_win is None:
        max_win = N // 4
    
    windows = np.logspace(np.log10(min_win), np.log10(max_win), n_wins).astype(int)
    windows = np.unique(windows)
    
    F_n = np.zeros(len(windows))
    
    for i, n in enumerate(windows):
        n_seg = N // n
        F = []
        for v in range(n_seg):
            segment = y[v*n:(v+1)*n]
            x = np.arange(n)
            coeffs = np.polyfit(x, segment, 1)
            fit = np.polyval(coeffs, x)
            F.append(np.sqrt(np.mean((segment - fit)**2)))
        F_n[i] = np.mean(F)
    
    log_n = np.log(windows)
    log_F = np.log(F_n + 1e-10)
    alpha, _ = np.polyfit(log_n, log_F, 1)
    
    return alpha

# Calculate DFA
dfa_results = {}
print("\nCalculating DFA scaling exponents...")

for pid in participants.keys():
    df = data_dict[pid]
    dfa_results[pid] = {}
    
    for var in test_vars:
        data = df[var].values
        alpha = dfa_simple(data)
        dfa_results[pid][var] = alpha

# Visualize
fig, ax = plt.subplots(figsize=(12, 6))

x = np.arange(len(test_vars))

for i, (pid, color) in enumerate(zip(participants.keys(), colors_p)):
    offset = width * (i - 1)
    values = [dfa_results[pid][var] for var in test_vars]
    ax.bar(x + offset, values, width, label=pid, alpha=0.8, 
          edgecolor='black', linewidth=1, color=color)

ax.axhline(y=0.5, color='red', linestyle='--', linewidth=2, 
          alpha=0.5, label='White noise (α=0.5)')
ax.axhline(y=1.0, color='orange', linestyle='--', linewidth=2, 
          alpha=0.5, label='1/f noise (α=1.0)')

ax.set_ylabel('DFA Exponent (α)', fontsize=11, fontweight='bold')
ax.set_xlabel('Variable', fontsize=11, fontweight='bold')
ax.set_title('DFA Analysis Comparison\n(α>0.5: Persistent, α=1.0: Scale-invariant)', 
            fontsize=12, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels([v.replace('_', '\n') for v in test_vars], fontsize=9)
ax.legend(fontsize=9, loc='upper left')
ax.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('/home/claude/multi_04_dfa.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: multi_04_dfa.png")

print("\nDFA exponents:")
for pid in participants.keys():
    print(f"\n{pid}:")
    for var in test_vars:
        alpha = dfa_results[pid][var]
        if alpha < 0.5:
            interp = "Anti-persistent"
        elif alpha < 0.7:
            interp = "Weak persistence"
        elif alpha < 1.0:
            interp = "Persistent"
        else:
            interp = "Non-stationary"
        print(f"  {var:20s}: α = {alpha:.3f} ({interp})")

# Continue with more analyses...
print("\n" + "=" * 80)
print("Part 1 Complete - Continuing with population analysis...")
print("=" * 80)
