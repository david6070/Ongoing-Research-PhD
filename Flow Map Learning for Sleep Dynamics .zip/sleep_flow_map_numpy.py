"""
Flow Map Learning for Sleep Dynamics - NumPy Implementation
Simplified version using classical ML instead of deep learning
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)
sns.set_style("whitegrid")

class SleepFlowMapLearner:
    """
    Flow Map Learning using scikit-learn models.
    Implements: x_{n+1} = x_n + N(x_n, x_{n-1}, ..., x_{n-nM})
    """
    
    def __init__(self, input_dim, memory_length=0, model_type='mlp'):
        self.input_dim = input_dim
        self.memory_length = memory_length
        self.model_type = model_type
        self.models = []  # One model per output dimension
        self.scaler = StandardScaler()
        self.history = {'train_loss': [], 'val_loss': []}
        
    def build_model(self):
        """Build regression models for each output dimension."""
        self.models = []
        
        for i in range(self.input_dim):
            if self.model_type == 'mlp':
                # Multi-layer Perceptron
                model = MLPRegressor(
                    hidden_layer_sizes=(50, 30, 20),
                    activation='relu',
                    solver='adam',
                    max_iter=1000,
                    learning_rate_init=0.001,
                    early_stopping=True,
                    validation_fraction=0.2,
                    n_iter_no_change=50,
                    random_state=42,
                    verbose=False
                )
            elif self.model_type == 'rf':
                # Random Forest
                model = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=10,
                    random_state=42,
                    n_jobs=-1
                )
            elif self.model_type == 'gbm':
                # Gradient Boosting
                model = GradientBoostingRegressor(
                    n_estimators=100,
                    max_depth=5,
                    learning_rate=0.1,
                    random_state=42
                )
            else:
                raise ValueError(f"Unknown model type: {self.model_type}")
            
            self.models.append(model)
        
        return self.models
    
    def prepare_sequences(self, data, sequence_length=10):
        """Prepare training data with memory structure."""
        n_samples = len(data)
        X_all = []
        y_all = []
        
        min_length = self.memory_length + sequence_length + 1
        
        if n_samples < min_length:
            raise ValueError(f"Data too short. Need at least {min_length} samples.")
        
        for i in range(self.memory_length, n_samples - 1):
            # Input: current state + memory
            memory_states = []
            for m in range(self.memory_length + 1):
                memory_states.append(data[i - m])
            X_seq = np.concatenate(memory_states)
            
            # Output: next state (residual from current state)
            current_state = data[i]
            next_state = data[i + 1]
            y_residual = next_state - current_state
            
            X_all.append(X_seq)
            y_all.append(y_residual)
        
        return np.array(X_all), np.array(y_all)
    
    def train(self, X_train, y_train, verbose=True):
        """Train the flow map models."""
        if len(self.models) == 0:
            self.build_model()
        
        if verbose:
            print(f"Training {self.input_dim} {self.model_type.upper()} models...")
        
        for i in range(self.input_dim):
            if verbose:
                print(f"  Training model for dimension {i+1}/{self.input_dim}...", end='')
            
            self.models[i].fit(X_train, y_train[:, i])
            
            if verbose:
                # Get training score
                train_pred = self.models[i].predict(X_train)
                train_mse = mean_squared_error(y_train[:, i], train_pred)
                print(f" MSE: {train_mse:.6f}")
        
        if verbose:
            print("Training complete!")
        
        return self
    
    def predict_trajectory(self, initial_state, n_steps):
        """Predict trajectory by recursively applying the flow map."""
        trajectory = []
        current_memory = [initial_state[i] for i in range(len(initial_state))]
        
        for step in range(n_steps):
            # Prepare input
            input_seq = np.concatenate(current_memory[:self.memory_length + 1])
            input_seq = input_seq.reshape(1, -1)
            
            # Predict residual for each dimension
            residuals = np.zeros(self.input_dim)
            for i in range(self.input_dim):
                residuals[i] = self.models[i].predict(input_seq)[0]
            
            # Apply flow map: x_{n+1} = x_n + residual
            current_state = current_memory[0]
            next_state = current_state + residuals
            
            trajectory.append(next_state)
            
            # Update memory
            current_memory = [next_state] + current_memory[:self.memory_length]
        
        return np.array(trajectory)
    
    def evaluate(self, X_test, y_test):
        """Evaluate model on test data."""
        metrics = {}
        
        for i in range(self.input_dim):
            y_pred = self.models[i].predict(X_test)
            
            metrics[f'dim_{i}_mse'] = mean_squared_error(y_test[:, i], y_pred)
            metrics[f'dim_{i}_mae'] = mean_absolute_error(y_test[:, i], y_pred)
            metrics[f'dim_{i}_r2'] = r2_score(y_test[:, i], y_pred)
        
        return metrics


def load_and_prepare_data(filepath):
    """Load sleep data and create time series."""
    print("Loading sleep data...")
    df = pd.read_csv(filepath)
    df = df.sort_values(by='date').reset_index(drop=True)
    
    print(f"  Loaded {len(df)} records from {df['date'].min()} to {df['date'].max()}")
    
    # Select features
    features = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct']
    
    # Check which features exist
    existing_features = [f for f in features if f in df.columns]
    
    if len(existing_features) == 0:
        print("  Creating percentage features from raw data...")
        # Calculate percentages
        total_sleep = df['deep_min'] + df['light_min'] + df['rem_min']
        total_time = total_sleep + df['wake_min']
        
        df['deep_pct'] = (df['deep_min'] / total_time * 100).fillna(0)
        df['light_pct'] = (df['light_min'] / total_time * 100).fillna(0)
        df['rem_pct'] = (df['rem_min'] / total_time * 100).fillna(0)
        df['wake_pct'] = (df['wake_min'] / total_time * 100).fillna(0)
        
        existing_features = features
    
    # Extract time series
    time_series = df[existing_features].values
    time_series = np.nan_to_num(time_series, nan=0.0)
    
    print(f"  Time series shape: {time_series.shape}")
    print(f"  Features: {existing_features}")
    
    return time_series, existing_features, df


def plot_time_series(data, feature_names, save_path):
    """Plot time series data."""
    n_features = data.shape[1]
    fig, axes = plt.subplots(n_features, 1, figsize=(14, 3*n_features))
    
    if n_features == 1:
        axes = [axes]
    
    for i in range(n_features):
        axes[i].plot(data[:, i], linewidth=1.5, alpha=0.8)
        axes[i].set_ylabel(feature_names[i], fontsize=10)
        axes[i].grid(True, alpha=0.3)
        axes[i].set_xlim(0, len(data))
        
        if i == n_features - 1:
            axes[i].set_xlabel('Time (days)', fontsize=10)
    
    plt.suptitle('Sleep Time Series Data', fontsize=14, y=0.995)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {save_path}")


def compare_trajectories(reference, predicted, feature_names, save_path, window=None):
    """Compare reference and predicted trajectories."""
    if window is not None:
        start, end = window
        reference = reference[start:end]
        predicted = predicted[start:end]
    
    n_features = reference.shape[1]
    fig = plt.figure(figsize=(16, 3*n_features))
    
    for i in range(n_features):
        # Trajectory comparison
        ax1 = plt.subplot(n_features, 2, 2*i + 1)
        time_steps = np.arange(len(reference))
        ax1.plot(time_steps, reference[:, i], label='Reference', 
                linewidth=2, alpha=0.7, color='blue')
        ax1.plot(time_steps, predicted[:, i], label='Predicted', 
                linewidth=2, alpha=0.7, linestyle='--', color='orange')
        ax1.set_ylabel(feature_names[i], fontsize=10)
        ax1.legend(fontsize=9)
        ax1.grid(True, alpha=0.3)
        if i == 0:
            ax1.set_title('Trajectory Comparison', fontsize=11)
        
        # Error
        ax2 = plt.subplot(n_features, 2, 2*i + 2)
        error = np.abs(reference[:, i] - predicted[:, i])
        ax2.semilogy(time_steps, error + 1e-10, linewidth=2, color='red', alpha=0.7)
        ax2.set_ylabel(f'|Error|', fontsize=10)
        ax2.grid(True, alpha=0.3)
        if i == 0:
            ax2.set_title('Absolute Error (log scale)', fontsize=11)
        
        if i == n_features - 1:
            ax1.set_xlabel('Time Step', fontsize=10)
            ax2.set_xlabel('Time Step', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {save_path}")


def plot_phase_space(reference, predicted, idx1, idx2, feature_names, save_path):
    """Plot phase space comparison."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    ax1.plot(reference[:, idx1], reference[:, idx2], 
            linewidth=0.8, alpha=0.6, color='blue')
    ax1.set_xlabel(feature_names[idx1], fontsize=11)
    ax1.set_ylabel(feature_names[idx2], fontsize=11)
    ax1.set_title('Reference Phase Plot', fontsize=12)
    ax1.grid(True, alpha=0.3)
    
    ax2.plot(predicted[:, idx1], predicted[:, idx2], 
            linewidth=0.8, alpha=0.6, color='orange')
    ax2.set_xlabel(feature_names[idx1], fontsize=11)
    ax2.set_ylabel(feature_names[idx2], fontsize=11)
    ax2.set_title('Predicted Phase Plot', fontsize=12)
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {save_path}")


def plot_distributions(reference, predicted, feature_names, save_path):
    """Plot histogram comparisons."""
    n_features = reference.shape[1]
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()
    
    for i in range(n_features):
        axes[i].hist(reference[:, i], bins=25, alpha=0.6, 
                    label='Reference', density=True, color='blue')
        axes[i].hist(predicted[:, i], bins=25, alpha=0.6, 
                    label='Predicted', density=True, color='orange')
        axes[i].set_xlabel(feature_names[i], fontsize=10)
        axes[i].set_ylabel('Density', fontsize=10)
        axes[i].legend(fontsize=9)
        axes[i].grid(True, alpha=0.3)
    
    plt.suptitle('Distribution Comparison', fontsize=14)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {save_path}")


def compute_metrics(reference, predicted, feature_names):
    """Compute comprehensive metrics."""
    metrics = {}
    
    for i, name in enumerate(feature_names):
        ref = reference[:, i]
        pred = predicted[:, i]
        
        metrics[f'{name}_MSE'] = np.mean((ref - pred)**2)
        metrics[f'{name}_MAE'] = np.mean(np.abs(ref - pred))
        metrics[f'{name}_RMSE'] = np.sqrt(metrics[f'{name}_MSE'])
        
        if np.std(ref) > 0 and np.std(pred) > 0:
            metrics[f'{name}_corr'] = np.corrcoef(ref, pred)[0, 1]
        else:
            metrics[f'{name}_corr'] = 0.0
        
        metrics[f'{name}_mean_diff'] = abs(np.mean(ref) - np.mean(pred))
        metrics[f'{name}_std_diff'] = abs(np.std(ref) - np.std(pred))
    
    return metrics


if __name__ == "__main__":
    print("=" * 70)
    print("FLOW MAP LEARNING FOR SLEEP DYNAMICS - NumPy Implementation")
    print("=" * 70)
