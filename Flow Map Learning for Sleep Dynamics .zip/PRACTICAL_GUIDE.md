# Flow Map Learning for Sleep - Practical Guide

**Prepared by:** David Olutunde Daniel  
**Submitted to:** Prof. Yan Cao  
**Date:** February 9, 2026

---

## Quick Start

### What is Flow Map Learning?

Flow map learning models how systems **evolve over time** by learning the "flow" from one state to the next. Instead of just describing what sleep looks like, it learns **how sleep changes**.

Think of it like weather forecasting:
- Traditional sleep analysis → describing yesterday's weather
- Flow map learning → predicting tomorrow's weather based on recent patterns

### The Core Equation

```
tomorrow's_sleep = today's_sleep + learned_change(recent_history)
```

More formally:
```python
x_{n+1} = x_n + N(x_n, x_{n-1}, ..., x_{n-5})
```

Where:
- x_n = sleep state on night n
- N = neural network
- Memory of 5 previous nights

---

## Installation & Setup

### Required Libraries

```bash
pip install numpy pandas matplotlib seaborn scikit-learn scipy
```

### Files Needed

1. `sleep_flow_map_numpy.py` - Core implementation
2. `run_analysis.py` - Main analysis script
3. Your sleep data CSV

---

## Understanding Your Data

### Required Format

CSV with these columns (at minimum):
- `date` - Date of sleep record
- `deep_pct` - Deep sleep percentage
- `light_pct` - Light sleep percentage
- `rem_pct` - REM sleep percentage
- `wake_pct` - Wake percentage

Alternative: Raw minutes (deep_min, light_min, etc.) - will be auto-converted

### Data Preparation

```python
from sleep_flow_map_numpy import load_and_prepare_data

# Load and create time series
time_series, feature_names, df = load_and_prepare_data('your_data.csv')

# Check the data
print(f"Shape: {time_series.shape}")  # (n_nights, n_features)
print(f"Features: {feature_names}")
```

---

## Running the Analysis

### Basic Usage

```python
from sleep_flow_map_numpy import SleepFlowMapLearner
from sklearn.preprocessing import StandardScaler

# 1. Normalize data
scaler = StandardScaler()
normalized = scaler.fit_transform(time_series)

# 2. Split train/test (temporal split!)
split = int(len(normalized) * 0.8)
train = normalized[:split]
test = normalized[split:]

# 3. Create learner
learner = SleepFlowMapLearner(
    input_dim=4,           # 4 sleep features
    memory_length=5,       # Use 5 previous nights
    model_type='mlp'       # Neural network
)

# 4. Prepare sequences
X_train, y_train = learner.prepare_sequences(train)

# 5. Train
learner.train(X_train, y_train)

# 6. Predict
initial_memory = [train[-i-1] for i in range(6)]
initial_memory.reverse()
predictions = learner.predict_trajectory(initial_memory, len(test))

# 7. Denormalize
predictions_real = scaler.inverse_transform(predictions)
test_real = scaler.inverse_transform(test)
```

### Full Pipeline

Just run:
```bash
python run_analysis.py
```

This will:
1. Load your data
2. Train the model
3. Generate all visualizations
4. Compute metrics
5. Test long-term stability

---

## Interpreting Results

### 1. Training Metrics

**R² Score**: How much variance the model explains
- 0.0 = no better than random
- 1.0 = perfect fit
- 0.5-0.6 = reasonable for sleep (lots of randomness)

**MSE/MAE**: Average prediction error
- MSE = Mean Squared Error (penalizes large errors)
- MAE = Mean Absolute Error (average difference)
- Lower is better

### 2. Test Performance

**Correlation**: How well predictions track reality
- -1 to +1 scale
- 0 = no relationship
- > 0.5 = good tracking
- < 0 might indicate inverse relationship

**Bounded Error**: Most important for sleep!
- Predictions should stay in 0-100% range
- No "negative sleep" or "200% wake"
- Bounded = stable model

### 3. Autocorrelation Match

Measures temporal structure preservation:
- 1.0 = perfect match
- 0.7+ = very good
- 0.5+ = acceptable
- < 0.3 = poor temporal modeling

### 4. Phase Space

Visual check of dynamics:
- **Reference and predicted should overlap in shape**
- Clustering patterns should match
- Bounds should align
- Not about exact trajectory match!

---

## Configuration Options

### Memory Length

```python
memory_length = 5  # Default: 5 nights
```

**How to choose:**
- Too small (1-2): Can't capture patterns
- Too large (10+): Overfitting, slow training
- Sweet spot: 3-7 for daily sleep
- For weekly patterns: 7-14

### Model Type

```python
model_type = 'mlp'  # Options: 'mlp', 'rf', 'gbm'
```

**Comparison:**
- `mlp`: Neural network, best for complex patterns
- `rf`: Random forest, fast, interpretable
- `gbm`: Gradient boosting, often most accurate

### Train/Test Split

```python
TRAIN_SPLIT = 0.8  # 80% train, 20% test
```

**Important:** Always use **temporal split** (first 80% vs last 20%)
- Never shuffle sleep data!
- Recent data should be test set
- Mimics real prediction scenario

---

## Common Issues & Solutions

### Issue 1: "Data too short"

**Error**: `ValueError: Data too short. Need at least X samples.`

**Solution**: Need `memory_length + sequence_length + 1` samples minimum
- With memory=5, need at least ~20 nights
- Reduce memory_length if dataset is small

### Issue 2: Poor predictions (high MAE)

**Possible causes:**
1. **Insufficient data**: Need 50+ nights for training
2. **Too much noise**: Clean outliers first
3. **Wrong features**: Try different sleep metrics
4. **No patterns**: Some people's sleep is just random!

**Solutions:**
- Increase training data
- Add more features (stress, exercise, etc.)
- Try ensemble models (Random Forest)
- Accept that sleep has inherent randomness

### Issue 3: Unstable long-term predictions

**Symptoms**: Predictions go negative or >100%

**Solutions:**
1. Increase training epochs
2. Reduce memory length
3. Add regularization
4. Use gradient boosting instead of MLP

### Issue 4: Model won't train

**Common causes:**
- Missing values in data (use `fillna()`)
- Non-numeric features
- Incompatible sklearn version

**Fix:**
```python
# Clean data first
data = data.fillna(method='ffill')  # Forward fill
data = data.select_dtypes(include=[np.number])  # Only numbers
```

---

## Advanced Usage

### Adding Custom Features

```python
# Example: Add sleep duration
df['duration_hours'] = (df['deep_min'] + df['light_min'] + 
                        df['rem_min'] + df['wake_min']) / 60

# Example: Add previous night's stress
df['stress_lag1'] = df['stress_score'].shift(1)

# Create time series with new features
features = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct', 
            'duration_hours', 'stress_lag1']
time_series = df[features].fillna(0).values
```

### Multi-step Ahead Prediction

```python
# Predict 7 days ahead
week_ahead = learner.predict_trajectory(initial_memory, 7)

# Compare different prediction horizons
for days in [1, 3, 7, 14]:
    pred = learner.predict_trajectory(initial_memory, days)
    print(f"{days}-day MAE: {compute_mae(test[:days], pred)}")
```

### Ensemble Predictions

```python
# Train multiple models
models = []
for model_type in ['mlp', 'rf', 'gbm']:
    learner = SleepFlowMapLearner(4, 5, model_type)
    learner.train(X_train, y_train)
    models.append(learner)

# Average predictions
predictions = []
for model in models:
    pred = model.predict_trajectory(initial_memory, len(test))
    predictions.append(pred)

ensemble_pred = np.mean(predictions, axis=0)
```

---

## Optimization Tips

### Hyperparameter Tuning

```python
from sklearn.model_selection import GridSearchCV

# For MLP
param_grid = {
    'hidden_layer_sizes': [(30,20), (50,30,20), (100,50)],
    'learning_rate_init': [0.001, 0.01],
    'max_iter': [500, 1000]
}

# For Random Forest
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [5, 10, 15],
    'min_samples_split': [2, 5, 10]
}
```

### Feature Engineering

Best practices:
1. **Normalize**: Always standardize features
2. **Lag features**: Previous nights very important
3. **Rolling averages**: Smooth noise
4. **Temporal features**: Day of week, weekend indicator
5. **External factors**: Weather, stress, exercise

### Cross-Validation

```python
from sklearn.model_selection import TimeSeriesSplit

tscv = TimeSeriesSplit(n_splits=5)

scores = []
for train_idx, test_idx in tscv.split(X):
    learner.train(X[train_idx], y[train_idx])
    score = learner.evaluate(X[test_idx], y[test_idx])
    scores.append(score)

print(f"CV Score: {np.mean(scores):.3f} ± {np.std(scores):.3f}")
```

---

## Validation Checklist

Before trusting your model, verify:

- [ ] Training loss decreased over epochs
- [ ] Validation loss stopped decreasing (converged)
- [ ] Test predictions stay in physical bounds (0-100%)
- [ ] Autocorrelation structure preserved (>0.3 match)
- [ ] Phase space plots show similar patterns
- [ ] Distributions roughly match
- [ ] No systematic bias (mean differences small)
- [ ] Long-term predictions don't diverge

If any fail, revisit model configuration or data quality.

---

## Comparison to Other Methods

### vs. Traditional Sleep Statistics

**Traditional**: Average deep sleep = 14%
- ✓ Simple to understand
- ✓ Standardized
- ✗ No temporal dynamics
- ✗ Can't predict future

**Flow Map**: Learn evolution operator
- ✓ Captures dynamics
- ✓ Can forecast
- ✓ Finds patterns
- ✗ More complex
- ✗ Needs more data

### vs. Simple Time Series Models

**ARIMA/SARIMA**: Linear time series
- ✓ Fast
- ✓ Interpretable
- ✗ Assumes linearity
- ✗ Can't capture complex patterns

**Flow Map**: Nonlinear dynamics
- ✓ Handles complexity
- ✓ Memory-based
- ✓ Better for chaotic systems
- ✗ Harder to interpret

### vs. LSTMs/RNNs

**LSTM**: Recurrent neural network
- ✓ Very powerful
- ✓ Automatic feature learning
- ✗ Needs lots of data
- ✗ Black box
- ✗ Computationally expensive

**Flow Map**: Simpler architecture
- ✓ Less data needed
- ✓ Faster training
- ✓ More interpretable structure
- ✗ Manual feature engineering

---

### For Researchers

1. **Publish findings**: Compare to baseline models
2. **Add covariates**: Stress, medication, environment
3. **Multi-subject**: Pool data, find population patterns
4. **Clinical validation**: Test on sleep disorders

### For Clinicians

1. **Patient monitoring**: Track sleep evolution
2. **Treatment response**: Predict intervention effects
3. **Risk stratification**: Identify deteriorating patterns
4. **Personalization**: Individual flow maps

### For Personal Use

1. **Self-tracking**: Understand your sleep dynamics
2. **Behavior experiments**: Test sleep hygiene changes
3. **Pattern recognition**: Find your sleep cycles
4. **Optimization**: Improve sleep habits

---

## Further Reading

### Papers

1. **Churchill & Xiu (2022)**: Original flow map paper
   - Deep learning of chaotic systems
   - ResNet architecture for dynamics

2. **Hermans et al. (2022)**: Sleep representations review
   - All methods for analyzing sleep
   - Comprehensive comparison

3. **Stephansen et al. (2018)**: Hypnodensity
   - Probabilistic sleep staging
   - Clinical applications

### Books

- **Dynamics and Bifurcations** (Hale & Kocak)
- **Deep Learning** (Goodfellow et al.)
- **Principles and Practice of Sleep Medicine** (Kryger et al.)

### Online Resources

- Scikit-learn documentation: https://scikit-learn.org
- Sleep research databases: https://sleepdata.org
- Time series in Python: https://www.machinelearningplus.com

---

## Citation

If you use this code in research, please cite:

```bibtex
@software{sleep_flow_map_2026,
  title = {Flow Map Learning for Sleep Dynamics},
  author = {[Your Name]},
  year = {2026},
  note = {Based on Churchill \& Xiu (2022) flow map framework}
}
```

---

## Support & Contribution

### Found a bug?
Open an issue with:
- Your data format
- Error message
- Expected vs actual behavior

### Want to contribute?
Ideas welcome:
- Additional model types
- New visualizations
- Clinical validation studies
- Multi-modal integration

---

**Last updated**: February 7, 2026  
**Version**: 1.0  
**License**: MIT (adapt as needed)
