"""
Comprehensive Stress-Sleep Analysis with Cycle Detection
Analyzes the relationship between stress and sleep dynamics
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, signal
from scipy.fft import fft, fftfreq
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

sns.set_style("whitegrid")
plt.rcParams['figure.dpi'] = 100

print("=" * 80)
print("STRESS-SLEEP DYNAMICS ANALYSIS")
print("=" * 80)
print()

# ============================================================================
# STEP 1: Load and Prepare Data
# ============================================================================
print("STEP 1: Loading and Preparing Data")
print("-" * 80)

df = pd.read_csv('/mnt/user-data/uploads/final_separated_sleep_ids.csv')
df['date'] = pd.to_datetime(df['date'])
df = df.sort_values('date').reset_index(drop=True)

print(f"Dataset: {len(df)} nights from {df['date'].min().date()} to {df['date'].max().date()}")
print(f"Duration: {(df['date'].max() - df['date'].min()).days} days")

# Create stress composite score
stress_cols = ['stress_score_health', 'stress_score_job', 'stress_score_personality']
df['stress_composite'] = df[stress_cols].mean(axis=1)
df['stress_any'] = df[stress_cols].max(axis=1)  # Maximum stress across categories

# Count stress observations
stress_available = df[stress_cols].notna().any(axis=1).sum()
print(f"\nStress data available: {stress_available}/{len(df)} nights ({stress_available/len(df)*100:.1f}%)")

# Categorize stress levels
df['stress_category'] = pd.cut(df['stress_any'], 
                               bins=[0, 1.5, 2.5, 5], 
                               labels=['Low (1)', 'Medium (2)', 'High (3-5)'],
                               include_lowest=True)

# Sleep quality metrics
df['total_sleep_min'] = df['deep_min'] + df['light_min'] + df['rem_min']
df['sleep_efficiency'] = (df['total_sleep_min'] / (df['total_sleep_min'] + df['wake_min']) * 100)
df['deep_sleep_ratio'] = df['deep_pct'] / (df['deep_pct'] + df['light_pct'] + df['rem_pct']) * 100

# Day of week
df['day_of_week'] = df['date'].dt.dayofweek
df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)
df['day_name'] = df['date'].dt.day_name()

print("\nStress distribution:")
print(df['stress_category'].value_counts().sort_index())

print("\nSleep metrics summary:")
for metric in ['total_sleep_min', 'sleep_efficiency', 'deep_pct', 'rem_pct', 'wake_pct']:
    print(f"  {metric:20s}: mean={df[metric].mean():6.2f}, std={df[metric].std():6.2f}")

# ============================================================================
# STEP 2: Stress-Sleep Correlation Analysis
# ============================================================================
print("\n" + "=" * 80)
print("STEP 2: Stress-Sleep Correlation Analysis")
print("-" * 80)

# Select variables for correlation
correlation_vars = {
    'stress_composite': 'Composite Stress',
    'stress_score_health': 'Health Stress',
    'stress_score_job': 'Job Stress',
    'stress_score_personality': 'Personality Stress',
    'deep_pct': 'Deep Sleep %',
    'light_pct': 'Light Sleep %',
    'rem_pct': 'REM Sleep %',
    'wake_pct': 'Wake %',
    'sleep_efficiency': 'Sleep Efficiency',
    'total_sleep_min': 'Total Sleep (min)'
}

# Compute correlation matrix
corr_data = df[list(correlation_vars.keys())].copy()
corr_matrix = corr_data.corr()

# Plot correlation heatmap
fig, ax = plt.subplots(figsize=(12, 10))
mask = np.triu(np.ones_like(corr_matrix), k=1)
sns.heatmap(corr_matrix, 
            mask=mask,
            annot=True, 
            fmt='.3f',
            cmap='coolwarm',
            center=0,
            vmin=-1, vmax=1,
            square=True,
            linewidths=0.5,
            cbar_kws={'label': 'Correlation Coefficient'},
            xticklabels=[correlation_vars[k] for k in corr_matrix.columns],
            yticklabels=[correlation_vars[k] for k in corr_matrix.index])
plt.title('Stress-Sleep Correlation Matrix', fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('/home/claude/stress_01_correlation_matrix.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_01_correlation_matrix.png")

# Print significant correlations with stress
print("\nSignificant correlations with stress (|r| > 0.3):")
stress_corrs = corr_matrix['stress_composite'].drop('stress_composite').sort_values()
for var, corr in stress_corrs.items():
    if abs(corr) > 0.3 and not pd.isna(corr):
        direction = "↑" if corr > 0 else "↓"
        print(f"  {direction} {correlation_vars[var]:25s}: r = {corr:+.3f}")

# ============================================================================
# STEP 3: Stress Impact on Sleep Stages
# ============================================================================
print("\n" + "=" * 80)
print("STEP 3: Stress Impact on Sleep Stages")
print("-" * 80)

# Filter data with stress information
df_stress = df[df['stress_any'].notna()].copy()
print(f"Analyzing {len(df_stress)} nights with stress data")

# Group by stress category
sleep_metrics = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct', 'sleep_efficiency']

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for idx, metric in enumerate(sleep_metrics):
    ax = axes[idx]
    
    # Box plot
    data_to_plot = [df_stress[df_stress['stress_category'] == cat][metric].dropna() 
                    for cat in ['Low (1)', 'Medium (2)', 'High (3-5)']]
    
    bp = ax.boxplot(data_to_plot, 
                    labels=['Low\n(1)', 'Medium\n(2)', 'High\n(3-5)'],
                    patch_artist=True,
                    notch=True,
                    showmeans=True,
                    meanprops=dict(marker='D', markerfacecolor='red', markersize=6))
    
    # Color boxes
    colors = ['#90EE90', '#FFD700', '#FF6B6B']
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    
    ax.set_xlabel('Stress Level', fontsize=10, fontweight='bold')
    ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=10, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')
    
    # Statistical test (Kruskal-Wallis)
    if len(data_to_plot[0]) > 0 and len(data_to_plot[1]) > 0 and len(data_to_plot[2]) > 0:
        h_stat, p_val = stats.kruskal(*data_to_plot)
        sig_marker = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else "ns"
        ax.set_title(f'{metric.replace("_", " ").title()}\n(p={p_val:.4f} {sig_marker})', 
                    fontsize=11, fontweight='bold')

# Remove extra subplot
fig.delaxes(axes[5])

plt.suptitle('Sleep Metrics by Stress Level', fontsize=14, fontweight='bold', y=0.995)
plt.tight_layout()
plt.savefig('/home/claude/stress_02_sleep_by_stress_level.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_02_sleep_by_stress_level.png")

# Print summary statistics
print("\nSleep metrics by stress level:")
for metric in sleep_metrics:
    print(f"\n{metric}:")
    grouped = df_stress.groupby('stress_category')[metric].agg(['mean', 'std', 'count'])
    print(grouped.to_string())

# ============================================================================
# STEP 4: Temporal Stress-Sleep Dynamics
# ============================================================================
print("\n" + "=" * 80)
print("STEP 4: Temporal Stress-Sleep Dynamics")
print("-" * 80)

# Plot time series with stress overlay
fig, axes = plt.subplots(4, 1, figsize=(16, 12))

sleep_vars = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct']
colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']

for idx, (var, color) in enumerate(zip(sleep_vars, colors)):
    ax = axes[idx]
    
    # Plot sleep metric
    ax.plot(df['date'], df[var], 'o-', color=color, linewidth=1.5, 
            markersize=4, alpha=0.7, label=var.replace('_', ' ').title())
    
    # Overlay stress as background color
    for i, row in df.iterrows():
        if pd.notna(row['stress_any']):
            stress_level = row['stress_any']
            if stress_level <= 1.5:
                bg_color = '#90EE90'
            elif stress_level <= 2.5:
                bg_color = '#FFD700'
            else:
                bg_color = '#FF6B6B'
            
            ax.axvspan(row['date'], row['date'] + pd.Timedelta(days=1), 
                      alpha=0.2, color=bg_color, zorder=0)
    
    ax.set_ylabel(var.replace('_', ' ').title() + ' (%)', fontsize=10, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend(loc='upper right', fontsize=9)
    
    if idx == 0:
        # Add legend for stress colors
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor='#90EE90', alpha=0.5, label='Low Stress (1)'),
                          Patch(facecolor='#FFD700', alpha=0.5, label='Med Stress (2)'),
                          Patch(facecolor='#FF6B6B', alpha=0.5, label='High Stress (3-5)')]
        ax.legend(handles=legend_elements, loc='upper left', fontsize=9, title='Stress Level')
    
    if idx == 3:
        ax.set_xlabel('Date', fontsize=10, fontweight='bold')

plt.suptitle('Sleep Stages Over Time with Stress Levels (Background Color)', 
            fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/stress_03_temporal_dynamics.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_03_temporal_dynamics.png")

# ============================================================================
# STEP 5: Lagged Effects (Stress → Next-Day Sleep)
# ============================================================================
print("\n" + "=" * 80)
print("STEP 5: Lagged Stress Effects on Sleep")
print("-" * 80)

# Create lagged stress variables
for lag in range(1, 4):
    df[f'stress_lag{lag}'] = df['stress_any'].shift(lag)

# Analyze correlation with lags
lag_correlations = {}
for lag in range(0, 4):
    lag_var = 'stress_any' if lag == 0 else f'stress_lag{lag}'
    correlations = {}
    for sleep_var in sleep_metrics:
        corr = df[[lag_var, sleep_var]].corr().iloc[0, 1]
        correlations[sleep_var] = corr
    lag_correlations[f'Lag {lag}'] = correlations

lag_df = pd.DataFrame(lag_correlations).T

# Plot lagged correlations
fig, ax = plt.subplots(figsize=(12, 6))
x = np.arange(len(sleep_metrics))
width = 0.2

for idx, (lag, row) in enumerate(lag_df.iterrows()):
    offset = width * (idx - 1.5)
    bars = ax.bar(x + offset, row.values, width, label=lag, alpha=0.8)

ax.set_xlabel('Sleep Metric', fontsize=11, fontweight='bold')
ax.set_ylabel('Correlation with Stress', fontsize=11, fontweight='bold')
ax.set_title('Lagged Stress Effects on Sleep\n(Lag 0 = Same night, Lag 1 = Next night, etc.)', 
            fontsize=12, fontweight='bold')
ax.set_xticks(x)
ax.set_xticklabels([m.replace('_', '\n') for m in sleep_metrics], fontsize=9)
ax.legend(fontsize=10)
ax.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
ax.grid(True, alpha=0.3, axis='y')
plt.tight_layout()
plt.savefig('/home/claude/stress_04_lagged_effects.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_04_lagged_effects.png")

print("\nLagged correlations:")
print(lag_df.to_string())

# ============================================================================
# STEP 6: Cycle Detection - Spectral Analysis
# ============================================================================
print("\n" + "=" * 80)
print("STEP 6: Cycle Detection via Spectral Analysis")
print("-" * 80)

# Prepare data for FFT (fill missing values with interpolation)
cycle_vars = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct', 'stress_any']

fig, axes = plt.subplots(3, 2, figsize=(16, 12))
axes = axes.flatten()

dominant_periods = {}

for idx, var in enumerate(cycle_vars):
    # Interpolate missing values
    data_series = df[var].interpolate(method='linear').fillna(method='bfill').fillna(method='ffill')
    
    # Remove trend (detrend)
    detrended = signal.detrend(data_series.values)
    
    # Apply window to reduce spectral leakage
    window = signal.windows.hann(len(detrended))
    windowed = detrended * window
    
    # Compute FFT
    n = len(windowed)
    yf = fft(windowed)
    xf = fftfreq(n, d=1.0)  # d=1 day
    
    # Only positive frequencies
    positive_freq_idx = xf > 0
    xf = xf[positive_freq_idx]
    yf = 2.0/n * np.abs(yf[positive_freq_idx])
    
    # Convert frequency to period (in days)
    periods = 1.0 / xf
    
    # Focus on periods between 2 and 30 days
    period_mask = (periods >= 2) & (periods <= 30)
    periods_filtered = periods[period_mask]
    power_filtered = yf[period_mask]
    
    # Find dominant periods
    # Get top 3 peaks
    peaks, properties = signal.find_peaks(power_filtered, height=0, prominence=0.5)
    if len(peaks) > 0:
        top_peaks = peaks[np.argsort(power_filtered[peaks])[-3:]][::-1]
        dominant_periods[var] = periods_filtered[top_peaks].tolist()
    else:
        dominant_periods[var] = []
    
    # Plot power spectrum
    ax = axes[idx]
    ax.plot(periods_filtered, power_filtered, linewidth=1.5, alpha=0.8)
    
    # Mark peaks
    if len(peaks) > 0:
        ax.plot(periods_filtered[peaks], power_filtered[peaks], 'ro', markersize=6, alpha=0.7)
        
        # Annotate top peak
        if len(top_peaks) > 0:
            top_period = periods_filtered[top_peaks[0]]
            top_power = power_filtered[top_peaks[0]]
            ax.annotate(f'{top_period:.1f} days', 
                       xy=(top_period, top_power),
                       xytext=(top_period, top_power * 1.2),
                       fontsize=9,
                       ha='center',
                       bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.6))
    
    ax.set_xlabel('Period (days)', fontsize=10, fontweight='bold')
    ax.set_ylabel('Power', fontsize=10, fontweight='bold')
    ax.set_title(f'{var.replace("_", " ").title()}\nSpectral Analysis', 
                fontsize=11, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(2, 30)
    
    # Add vertical lines for common cycles
    ax.axvline(x=7, color='green', linestyle='--', alpha=0.4, linewidth=1, label='Weekly')
    ax.axvline(x=14, color='blue', linestyle='--', alpha=0.4, linewidth=1, label='Bi-weekly')
    if idx == 0:
        ax.legend(fontsize=8, loc='upper right')

# Remove extra subplot
fig.delaxes(axes[5])

plt.suptitle('Cycle Detection: Spectral Analysis of Sleep and Stress', 
            fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/stress_05_spectral_cycles.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_05_spectral_cycles.png")

print("\nDetected dominant cycles (periods in days):")
for var, periods in dominant_periods.items():
    if len(periods) > 0:
        periods_str = ', '.join([f'{p:.1f}' for p in periods[:3]])
        print(f"  {var:20s}: {periods_str}")
    else:
        print(f"  {var:20s}: No significant cycles detected")

# ============================================================================
# STEP 7: Weekly Patterns
# ============================================================================
print("\n" + "=" * 80)
print("STEP 7: Weekly Patterns in Sleep and Stress")
print("-" * 80)

# Group by day of week
weekly_pattern = df.groupby('day_name')[sleep_metrics + ['stress_any']].mean()

# Reorder days
day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
weekly_pattern = weekly_pattern.reindex([d for d in day_order if d in weekly_pattern.index])

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for idx, metric in enumerate(sleep_metrics + ['stress_any']):
    ax = axes[idx]
    
    values = weekly_pattern[metric].values
    days_short = [d[:3] for d in weekly_pattern.index]
    
    # Bar plot
    colors_weekday = ['#FF6B6B' if d in ['Sat', 'Sun'] else '#4ECDC4' 
                     for d in days_short]
    bars = ax.bar(range(len(days_short)), values, color=colors_weekday, alpha=0.7, 
                  edgecolor='black', linewidth=1)
    
    # Connect with line
    ax.plot(range(len(days_short)), values, 'o-', color='darkblue', 
           linewidth=2, markersize=8, alpha=0.6)
    
    ax.set_xticks(range(len(days_short)))
    ax.set_xticklabels(days_short, fontsize=10, fontweight='bold')
    ax.set_ylabel(metric.replace('_', ' ').title(), fontsize=10, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='y')
    ax.set_title(metric.replace('_', ' ').title(), fontsize=11, fontweight='bold')

plt.suptitle('Weekly Patterns: Sleep and Stress by Day of Week\n(Red = Weekend, Teal = Weekday)', 
            fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/stress_06_weekly_patterns.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_06_weekly_patterns.png")

print("\nWeekly averages:")
print(weekly_pattern.to_string())

# Test weekend vs weekday differences
print("\nWeekend vs Weekday comparison:")
for metric in sleep_metrics:
    weekday_vals = df[df['is_weekend'] == 0][metric].dropna()
    weekend_vals = df[df['is_weekend'] == 1][metric].dropna()
    
    if len(weekday_vals) > 0 and len(weekend_vals) > 0:
        t_stat, p_val = stats.ttest_ind(weekday_vals, weekend_vals)
        weekday_mean = weekday_vals.mean()
        weekend_mean = weekend_vals.mean()
        diff = weekend_mean - weekday_mean
        
        sig = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else "ns"
        print(f"  {metric:20s}: Weekday={weekday_mean:6.2f}, Weekend={weekend_mean:6.2f}, "
              f"Diff={diff:+6.2f} (p={p_val:.4f} {sig})")

# ============================================================================
# STEP 8: Autocorrelation - Temporal Dependencies
# ============================================================================
print("\n" + "=" * 80)
print("STEP 8: Autocorrelation Analysis")
print("-" * 80)

max_lag = 14  # 2 weeks

fig, axes = plt.subplots(3, 2, figsize=(14, 12))
axes = axes.flatten()

for idx, var in enumerate(cycle_vars):
    data_series = df[var].dropna()
    
    if len(data_series) > max_lag:
        # Compute autocorrelation
        autocorr = [data_series.autocorr(lag=i) for i in range(max_lag + 1)]
        
        ax = axes[idx]
        ax.stem(range(max_lag + 1), autocorr, basefmt=' ')
        ax.axhline(y=0, color='black', linestyle='-', linewidth=0.8)
        
        # Add confidence interval (95%)
        conf_interval = 1.96 / np.sqrt(len(data_series))
        ax.axhline(y=conf_interval, color='red', linestyle='--', alpha=0.5, linewidth=1)
        ax.axhline(y=-conf_interval, color='red', linestyle='--', alpha=0.5, linewidth=1)
        ax.fill_between(range(max_lag + 1), conf_interval, -conf_interval, 
                        alpha=0.1, color='red')
        
        ax.set_xlabel('Lag (days)', fontsize=10, fontweight='bold')
        ax.set_ylabel('Autocorrelation', fontsize=10, fontweight='bold')
        ax.set_title(f'{var.replace("_", " ").title()}', fontsize=11, fontweight='bold')
        ax.grid(True, alpha=0.3)
        ax.set_xlim(-0.5, max_lag + 0.5)
        ax.set_ylim(-1, 1)

fig.delaxes(axes[5])

plt.suptitle('Autocorrelation Functions: Temporal Dependencies in Sleep and Stress\n(Red bands = 95% confidence interval)', 
            fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('/home/claude/stress_07_autocorrelation.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_07_autocorrelation.png")

# Print significant lags
print("\nSignificant autocorrelation lags (|r| > 1.96/√n):")
for var in cycle_vars:
    data_series = df[var].dropna()
    if len(data_series) > max_lag:
        conf_threshold = 1.96 / np.sqrt(len(data_series))
        autocorr = [data_series.autocorr(lag=i) for i in range(1, max_lag + 1)]
        significant_lags = [i+1 for i, ac in enumerate(autocorr) if abs(ac) > conf_threshold]
        
        if significant_lags:
            lags_str = ', '.join(map(str, significant_lags[:5]))  # First 5
            print(f"  {var:20s}: Lags {lags_str}")
        else:
            print(f"  {var:20s}: No significant lags")

# ============================================================================
# STEP 9: Principal Component Analysis
# ============================================================================
print("\n" + "=" * 80)
print("STEP 9: Principal Component Analysis (PCA)")
print("-" * 80)

# Select features for PCA
pca_features = ['deep_pct', 'light_pct', 'rem_pct', 'wake_pct', 
                'sleep_efficiency', 'total_sleep_min']

# Filter complete cases
df_pca = df[pca_features + ['stress_any']].dropna()
print(f"PCA on {len(df_pca)} complete observations")

# Standardize
X = df_pca[pca_features].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Fit PCA
pca = PCA()
X_pca = pca.fit_transform(X_scaled)

# Plot explained variance
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Scree plot
ax1.bar(range(1, len(pca.explained_variance_ratio_) + 1), 
        pca.explained_variance_ratio_ * 100,
        alpha=0.7, color='steelblue', edgecolor='black')
ax1.plot(range(1, len(pca.explained_variance_ratio_) + 1), 
        np.cumsum(pca.explained_variance_ratio_) * 100,
        'ro-', linewidth=2, markersize=8, label='Cumulative')
ax1.set_xlabel('Principal Component', fontsize=11, fontweight='bold')
ax1.set_ylabel('Variance Explained (%)', fontsize=11, fontweight='bold')
ax1.set_title('PCA Scree Plot', fontsize=12, fontweight='bold')
ax1.legend(fontsize=10)
ax1.grid(True, alpha=0.3, axis='y')
ax1.set_xticks(range(1, len(pca.explained_variance_ratio_) + 1))

# Biplot (PC1 vs PC2 with stress coloring)
ax2.scatter(X_pca[:, 0], X_pca[:, 1], 
           c=df_pca['stress_any'], cmap='RdYlGn_r',
           s=80, alpha=0.6, edgecolors='black', linewidth=0.5)

# Add feature vectors
for i, feature in enumerate(pca_features):
    ax2.arrow(0, 0, 
             pca.components_[0, i] * 3, pca.components_[1, i] * 3,
             head_width=0.1, head_length=0.1, fc='red', ec='red', alpha=0.7)
    ax2.text(pca.components_[0, i] * 3.3, pca.components_[1, i] * 3.3,
            feature.replace('_', '\n'), fontsize=9, ha='center', va='center',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))

ax2.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)', 
              fontsize=11, fontweight='bold')
ax2.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)', 
              fontsize=11, fontweight='bold')
ax2.set_title('PCA Biplot (colored by stress)', fontsize=12, fontweight='bold')
ax2.grid(True, alpha=0.3)
ax2.axhline(y=0, color='k', linestyle='-', linewidth=0.5)
ax2.axvline(x=0, color='k', linestyle='-', linewidth=0.5)

cbar = plt.colorbar(ax2.collections[0], ax=ax2)
cbar.set_label('Stress Level', fontsize=10, fontweight='bold')

plt.tight_layout()
plt.savefig('/home/claude/stress_08_pca_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_08_pca_analysis.png")

print("\nPCA Summary:")
print(f"  Variance explained by PC1: {pca.explained_variance_ratio_[0]*100:.2f}%")
print(f"  Variance explained by PC2: {pca.explained_variance_ratio_[1]*100:.2f}%")
print(f"  Cumulative (PC1+PC2): {np.sum(pca.explained_variance_ratio_[:2])*100:.2f}%")

print("\nComponent loadings:")
loadings = pd.DataFrame(
    pca.components_[:2].T,
    columns=['PC1', 'PC2'],
    index=pca_features
)
print(loadings.to_string())

# ============================================================================
# STEP 10: Clustering Analysis
# ============================================================================
print("\n" + "=" * 80)
print("STEP 10: Sleep Pattern Clustering")
print("-" * 80)

# K-means clustering
n_clusters = 3
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
df_pca['cluster'] = kmeans.fit_predict(X_scaled)

print(f"Identified {n_clusters} sleep pattern clusters")

# Plot clusters
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Cluster visualization in PCA space
ax1 = axes[0]
scatter = ax1.scatter(X_pca[:, 0], X_pca[:, 1], 
                     c=df_pca['cluster'], cmap='viridis',
                     s=100, alpha=0.6, edgecolors='black', linewidth=1)
ax1.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}%)', 
              fontsize=11, fontweight='bold')
ax1.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}%)', 
              fontsize=11, fontweight='bold')
ax1.set_title('Sleep Pattern Clusters (K-means, n=3)', fontsize=12, fontweight='bold')
ax1.grid(True, alpha=0.3)
plt.colorbar(scatter, ax=ax1, label='Cluster', ticks=[0, 1, 2])

# Cluster characteristics
ax2 = axes[1]
cluster_means = df_pca.groupby('cluster')[pca_features].mean()

x_pos = np.arange(len(pca_features))
width = 0.25

for i in range(n_clusters):
    offset = width * (i - 1)
    # Normalize to 0-1 scale for visualization
    values_normalized = (cluster_means.iloc[i] - cluster_means.min()) / (cluster_means.max() - cluster_means.min())
    ax2.bar(x_pos + offset, values_normalized, width, 
           label=f'Cluster {i}', alpha=0.8)

ax2.set_ylabel('Normalized Value', fontsize=11, fontweight='bold')
ax2.set_xlabel('Sleep Feature', fontsize=11, fontweight='bold')
ax2.set_title('Cluster Characteristics (Normalized)', fontsize=12, fontweight='bold')
ax2.set_xticks(x_pos)
ax2.set_xticklabels([f.replace('_', '\n') for f in pca_features], fontsize=9)
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('/home/claude/stress_09_clustering.png', dpi=300, bbox_inches='tight')
plt.close()
print("  Saved: stress_09_clustering.png")

print("\nCluster characteristics:")
print(cluster_means.to_string())

print("\nStress levels by cluster:")
stress_by_cluster = df_pca.groupby('cluster')['stress_any'].agg(['mean', 'std', 'count'])
print(stress_by_cluster.to_string())

# ============================================================================
# STEP 11: Summary Report
# ============================================================================
print("\n" + "=" * 80)
print("COMPREHENSIVE STRESS-SLEEP ANALYSIS SUMMARY")
print("=" * 80)

print("\n1. DATA OVERVIEW")
print(f"   • Total nights analyzed: {len(df)}")
print(f"   • Nights with stress data: {stress_available}")
print(f"   • Date range: {df['date'].min().date()} to {df['date'].max().date()}")
print(f"   • Duration: {(df['date'].max() - df['date'].min()).days} days")

print("\n2. STRESS DISTRIBUTION")
stress_counts = df['stress_category'].value_counts().sort_index()
for cat, count in stress_counts.items():
    print(f"   • {cat}: {count} nights ({count/len(df)*100:.1f}%)")

print("\n3. KEY CORRELATIONS")
top_corrs = corr_matrix['stress_composite'].drop(['stress_composite', 'stress_score_health', 
                                                   'stress_score_job', 'stress_score_personality']).abs().sort_values(ascending=False)
print("   Top stress-sleep correlations:")
for var, corr_val in top_corrs.head(3).items():
    actual_corr = corr_matrix['stress_composite'][var]
    direction = "↑ Higher stress → Higher" if actual_corr > 0 else "↓ Higher stress → Lower"
    print(f"   • {direction} {correlation_vars[var]}: |r|={corr_val:.3f}")

print("\n4. DETECTED CYCLES")
for var, periods in dominant_periods.items():
    if len(periods) > 0:
        print(f"   • {var:20s}: {periods[0]:.1f}-day cycle")

print("\n5. WEEKEND EFFECTS")
print("   Significant weekend vs weekday differences:")
for metric in sleep_metrics:
    weekday_vals = df[df['is_weekend'] == 0][metric].dropna()
    weekend_vals = df[df['is_weekend'] == 1][metric].dropna()
    
    if len(weekday_vals) > 0 and len(weekend_vals) > 0:
        t_stat, p_val = stats.ttest_ind(weekday_vals, weekend_vals)
        if p_val < 0.05:
            diff = weekend_vals.mean() - weekday_vals.mean()
            direction = "higher" if diff > 0 else "lower"
            print(f"   • {metric}: {abs(diff):.2f}% {direction} on weekends (p={p_val:.4f})")

print("\n6. SLEEP PATTERN CLUSTERS")
print(f"   • Identified {n_clusters} distinct sleep patterns")
print("   • Cluster-stress relationship:")
for i in range(n_clusters):
    mean_stress = stress_by_cluster.loc[i, 'mean']
    print(f"     - Cluster {i}: Average stress = {mean_stress:.2f}")

print("\n7. FILES GENERATED")
outputs = [
    'stress_01_correlation_matrix.png',
    'stress_02_sleep_by_stress_level.png',
    'stress_03_temporal_dynamics.png',
    'stress_04_lagged_effects.png',
    'stress_05_spectral_cycles.png',
    'stress_06_weekly_patterns.png',
    'stress_07_autocorrelation.png',
    'stress_08_pca_analysis.png',
    'stress_09_clustering.png'
]
for f in outputs:
    print(f"   ✓ {f}")

print("\n" + "=" * 80)
print("ANALYSIS COMPLETE!")
print("=" * 80)
print("\nKey insights:")
print("  • Stress-sleep relationships quantified")
print("  • Temporal cycles identified")
print("  • Weekly patterns revealed")
print("  • Sleep phenotypes discovered through clustering")
print("  • All visualizations saved for review")
print("=" * 80)
